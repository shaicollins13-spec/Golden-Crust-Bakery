/* Golden Crust Bakery — Part 3 JavaScript enhancements */
'use strict';

const bakeryProducts = [
  { name: 'Fresh Bread', category: 'bread', description: 'Classic everyday loaves for sandwiches, breakfast and family meals.', price: 25, image: 'images/bread.svg', alt: 'Illustration of a fresh artisan bread loaf' },
  { name: 'Breakfast Pastries', category: 'pastry', description: 'Sweet and buttery bakery treats for mornings and quick snacks.', price: 18, image: 'images/pastry.svg', alt: 'Illustration of golden breakfast pastries' },
  { name: 'Cupcakes', category: 'treat', description: 'Individual celebration treats for birthdays and small gatherings.', price: 20, image: 'images/cake.svg', alt: 'Illustration of a decorated cake representing sweet treats' },
  { name: 'Celebration Cakes', category: 'treat', description: 'Cake options for birthdays and other special occasions.', price: 250, image: 'images/cake.svg', alt: 'Illustration of a decorated celebration cake' }
];

function showFeedback(element, message, isError = false) {
  if (!element) return;
  element.textContent = message;
  element.classList.toggle('error', isError);
  element.classList.toggle('success', !isError);
}

// Product catalogue: generated from data, then searched, filtered and sorted in the browser.
const productList = document.querySelector('#product-list');
if (productList) {
  const search = document.querySelector('#product-search');
  const category = document.querySelector('#product-category');
  const sort = document.querySelector('#product-sort');
  const count = document.querySelector('#product-count');
  function renderProducts() {
    const term = search.value.trim().toLowerCase();
    let results = bakeryProducts.filter(product =>
      (category.value === 'all' || product.category === category.value) &&
      `${product.name} ${product.description}`.toLowerCase().includes(term)
    );
    if (sort.value === 'low') results.sort((a, b) => a.price - b.price);
    if (sort.value === 'high') results.sort((a, b) => b.price - a.price);
    if (sort.value === 'name') results.sort((a, b) => a.name.localeCompare(b.name));
    productList.innerHTML = results.map(product => `
      <article class="card product-card">
        <img class="product-image" src="${product.image}" alt="${product.alt}" loading="lazy">
        <h2>${product.name}</h2>
        <p>${product.description}</p>
        <p class="price">From R${product.price}</p>
        <a class="text-link" href="enquiry.html?product=${encodeURIComponent(product.name)}">Enquire about this product</a>
      </article>`).join('');
    count.textContent = results.length ? `Showing ${results.length} of ${bakeryProducts.length} products` : 'No products match your search. Try another keyword or category.';
  }
  [search, category, sort].forEach(control => control.addEventListener('input', renderProducts));
  renderProducts();
}

// Enquiry form: validates input and calculates an illustrative estimate, not a live quote.
const enquiryForm = document.querySelector('#enquiry-form');
if (enquiryForm) {
  const dateInput = document.querySelector('#needed-date');
  dateInput.min = new Date().toISOString().slice(0, 10);
  const params = new URLSearchParams(window.location.search);
  const selectedProduct = params.get('product');
  if (selectedProduct) {
    document.querySelector('#type').value = selectedProduct.toLowerCase().includes('cake') ? 'celebration' : 'product';
    document.querySelector('#message').value = `I would like to enquire about ${selectedProduct}. Please share more information.`;
  }
  enquiryForm.addEventListener('submit', event => {
    event.preventDefault();
    const feedback = document.querySelector('#enquiry-feedback');
    if (!enquiryForm.checkValidity()) {
      enquiryForm.reportValidity();
      showFeedback(feedback, 'Please correct the highlighted fields before continuing.', true);
      return;
    }
    const type = document.querySelector('#type').value;
    const quantity = Number(document.querySelector('#quantity').value);
    const estimatePrices = { product: 25, order: 25, celebration: 250 };
    if (Object.hasOwn(estimatePrices, type)) {
      const estimate = estimatePrices[type] * quantity;
      showFeedback(feedback, `Thank you, ${document.querySelector('#name').value.trim()}! Your enquiry has been checked. Indicative starting estimate: R${estimate.toFixed(2)} for ${quantity} item(s). Final pricing and availability must be confirmed by the bakery. We will use the contact details you supplied to follow up.`);
    } else {
      showFeedback(feedback, `Thank you, ${document.querySelector('#name').value.trim()}! Your ${type} enquiry has been validated. This project demo does not submit data to a live business, but your details are ready for follow-up in a real implementation.`);
    }
  });
  enquiryForm.addEventListener('reset', () => setTimeout(() => showFeedback(document.querySelector('#enquiry-feedback'), ''), 0));
}

// General contact form: validate, compile the details and open the visitor's email app.
const contactForm = document.querySelector('#contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', event => {
    event.preventDefault();
    const feedback = document.querySelector('#contact-feedback');
    if (!contactForm.checkValidity()) {
      contactForm.reportValidity();
      showFeedback(feedback, 'Please correct the highlighted fields before preparing your email.', true);
      return;
    }
    const data = new FormData(contactForm);
    const subject = `Golden Crust Bakery — ${data.get('messageType')}`;
    const body = [
      `Name: ${data.get('name')}`,
      `Email: ${data.get('email')}`,
      `Phone: ${data.get('phone') || 'Not provided'}`,
      `Message type: ${data.get('messageType')}`,
      '', 'Message:', data.get('message')
    ].join('\n');
    const mailto = `mailto:hello@goldencrust.example?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    showFeedback(feedback, 'Your email has been prepared. Your email application should open; review the recipient and press Send.');
    window.location.href = mailto;
  });
  contactForm.addEventListener('reset', () => setTimeout(() => showFeedback(document.querySelector('#contact-feedback'), ''), 0));
}

// Accessible image lightbox using a native dialog.
const galleryButtons = document.querySelectorAll('[data-lightbox]');
if (galleryButtons.length) {
  const dialog = document.createElement('dialog');
  dialog.className = 'lightbox-dialog';
  dialog.innerHTML = '<button class="lightbox-close" type="button" aria-label="Close enlarged image">×</button><img alt=""><p></p>';
  document.body.append(dialog);
  const image = dialog.querySelector('img');
  const caption = dialog.querySelector('p');
  dialog.querySelector('button').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  galleryButtons.forEach(button => button.addEventListener('click', () => {
    image.src = button.dataset.lightbox;
    image.alt = button.querySelector('img').alt;
    caption.textContent = button.dataset.caption || '';
    dialog.showModal();
  }));
}

// FAQ accordion: one item can be expanded at a time.
document.querySelectorAll('.accordion-trigger').forEach(trigger => {
  trigger.addEventListener('click', () => {
    const expanded = trigger.getAttribute('aria-expanded') === 'true';
    trigger.setAttribute('aria-expanded', String(!expanded));
    const panel = document.getElementById(trigger.getAttribute('aria-controls'));
    panel.hidden = expanded;
  });
});

// Leaflet map, with approximate proposed service-area markers only.
const mapElement = document.querySelector('#bakery-map');
if (mapElement && window.L) {
  const map = L.map(mapElement).setView([-25.7479, 28.2293], 11);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
  L.marker([-25.7479, 28.2293]).addTo(map).bindPopup('<strong>Pretoria Central</strong><br>Illustrative proposed service area');
  L.marker([-25.7830, 28.2750]).addTo(map).bindPopup('<strong>Menlyn area</strong><br>Illustrative proposed service area');
} else if (mapElement) {
  mapElement.textContent = 'The interactive map could not load. Please check your internet connection.';
}
